#horario

Sistema para armar tus posibles horario sin tantos retrasos
Disculpen la negligencia en la linea grafica...

  USO

Su uso es muy simple solo seleccionas la materia que deseas
inscribir y esta aparecera en la tabla inferior de la pagina
ademas de que sabras cuando tengas colisiones, cuenta con
filtros por seccion para buscar por profesores,seccion,asignatura
como un buscador, sientanse libres comentar,criticar o agregar 
issues

NOTA: cuando hay mas de una colision el sistema no deja 
registrar tu materia 